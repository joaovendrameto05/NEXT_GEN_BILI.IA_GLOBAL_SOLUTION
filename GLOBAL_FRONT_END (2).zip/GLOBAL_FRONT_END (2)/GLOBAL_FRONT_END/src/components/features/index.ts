export { Hero } from "./Hero";
export { Features } from "./Features";
export { About } from "./About";
export { Team } from "./Team";